# -*- coding: utf-8 -*-
__author__ = 'wangyi'

from thrift.transport import TSocket
from pyhbase.hbase import THBaseService
from pyhbase.hbase.ttypes import *
import traceback

class hbasedao():
    def __init__(self,_hbhost, _hbport):
        '''
        hbase 主机 端口设置
        :param _hbhost: hbase host
        :param _hbport: hbase port
        '''
        self.hbhost = _hbhost
        self.hbport = _hbport


    def close(self):
        '''
        退出后关闭客户端链接并清理
        :return:
        '''
        try:
            if self.transport is not None:
                self.transport.close()
        except:
            traceback.print_exc()


    def get(self, table, rowkey):
        '''
        获取
        :param table: 表名
        :param rowkey: 行键
        :return: 记录
        '''
        socket = TSocket.TSocket(self.hbhost, self.hbport)
        framed = False
        if framed:
            self.transport = TTransport.TFramedTransport(socket)
        else:
            self.transport = TTransport.TBufferedTransport(socket)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = THBaseService.Client(self.protocol)
        self.transport.open()
        tg = TGet(row=rowkey)
        res = self.client.get(table=table,tget =tg)
        self.close()
        return res

    def exists(self, table, rowkey):
        '''
        判断纪律是否存在, 存在返回True  不存在返回False
        :param table: 表名
        :param rowkey: 行键
        :return: 记录是否存在
        '''
        socket = TSocket.TSocket(self.hbhost, self.hbport)
        framed = False
        if framed:
            self.transport = TTransport.TFramedTransport(socket)
        else:
            self.transport = TTransport.TBufferedTransport(socket)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = THBaseService.Client(self.protocol)
        self.transport.open()
        tg = TGet(row=rowkey)
        res = self.client.exists(table=table,tget =tg)
        self.close()
        return res


    def put(self,table,rowkey,cvs):
        '''
        新增
        :param table: 表名
        :param rowkey: 行键
        :param cvs: 新增字段列表
        :return: 无
        '''
        socket = TSocket.TSocket(self.hbhost, self.hbport)
        framed = False
        if framed:
            self.transport = TTransport.TFramedTransport(socket)
        else:
            self.transport = TTransport.TBufferedTransport(socket)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = THBaseService.Client(self.protocol)
        self.transport.open()
        tp = TPut(row=rowkey, columnValues=cvs)
        self.client.put(table,tp)
        self.close()

    def incr(self,table,rowkey,cvs):
        '''
        增长量
        :param table:  表名称
        :param rowkey:  行键
        :param cvs: 增长字段 [TColumnIncrement(family="cf1",qualifier=cn,amount=-1)]
        :return: 无
        '''
        socket = TSocket.TSocket(self.hbhost, self.hbport)
        framed = False
        if framed:
            self.transport = TTransport.TFramedTransport(socket)
        else:
            self.transport = TTransport.TBufferedTransport(socket)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = THBaseService.Client(self.protocol)
        self.transport.open()
        incr = TIncrement(row=rowkey,columns=cvs)
        self.client.increment(table,incr)
        self.close()

    def open_scan(self,table,tscan):
        '''
        打开游标
        :param table: 表名称
        :param tscan: 条件
        :return: 游标id
        '''
        socket = TSocket.TSocket(self.hbhost, self.hbport)
        framed = False
        if framed:
            self.transport = TTransport.TFramedTransport(socket)
        else:
            self.transport = TTransport.TBufferedTransport(socket)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = THBaseService.Client(self.protocol)
        self.transport.open()
        return self.client.openScanner(table,tscan)

    def close_scan(self,scan_id):
        '''
        关闭游标
        :param scan_id:
        :return: 无
        '''
        try:
            self.client.closeScanner(scan_id)
        except:
            traceback.print_exc()
        self.close()

    def delete(self,table,rk):
        '''
        删除行记录
        :param table: 表
        :param rk: rowkey
        :return: 无
        '''
        socket = TSocket.TSocket(self.hbhost, self.hbport)
        framed = False
        if framed:
            self.transport = TTransport.TFramedTransport(socket)
        else:
            self.transport = TTransport.TBufferedTransport(socket)
        self.protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = THBaseService.Client(self.protocol)
        self.transport.open()
        td = TDelete(row=rk)
        self.client.deleteSingle(table, td)
        self.close()

if __name__ == "__main__":
    hd = hbasedao("hbase.zy.com",9099)
    print(hd.exists("g_zbzb","douyu:dinner"))