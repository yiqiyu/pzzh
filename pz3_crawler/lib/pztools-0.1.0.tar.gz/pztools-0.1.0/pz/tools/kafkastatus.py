# -*- coding: utf-8 -*-
__author__ = 'wangyi'

from pykafka  import KafkaClient
from pz.tools.datetimeutils import curr_ts
import signal


def work_in_time(func, timeout=0, *args):
    def handler(signum, frame):
        raise AssertionError

    try:
        signal.signal(signal.SIGALRM, handler)
        signal.alarm(timeout)
        ret = func(*args)
        signal.alarm(0)
        return ret
    except AssertionError:
        return -1

class kafkastatus():
    def __init__(self,_broker_hosts,_zookeeper_hosts,_queue_key,_consumer_group):
        self.client = KafkaClient(hosts=_broker_hosts, zookeeper_hosts=_zookeeper_hosts)
        self.topic = self.client.topics[_queue_key]
        self.balanced_consumer = self.topic.get_balanced_consumer(consumer_group=_consumer_group, auto_commit_enable=False)
    def status(self):
        earliest_offset = self.topic.earliest_available_offsets()
        _e_offset = 0
        for i in earliest_offset.keys():
            if _e_offset < earliest_offset[i].offset:
                _e_offset = earliest_offset[i].offset[0]

        latest_offset = self.topic.latest_available_offsets()
        _l_offset = 0
        for i in latest_offset.keys():
            if _l_offset < latest_offset[i].offset:
                _l_offset = latest_offset[i].offset[0]
        curr_time = curr_ts()
        commit_offset = work_in_time(self.get_commit_offset,1)
        return {"earliest_offset": _e_offset, "latest_offset": _l_offset, "curr_time": curr_time,
                "commit_offset": commit_offset}

    def get_commit_offset(self):
        commit_offset = 0
        for message in self.balanced_consumer:
            commit_offset = message.offset
            break
        return commit_offset

    def __del__(self):
        self.balanced_consumer.stop()

def storm_queue_status(_broker_hosts,_zookeeper_hosts):
    '''
    客户端各队列和消费组偏移状态
    :param _broker_hosts:  代理集群地址
    :param _zookeeper_hosts: zk集群地址
    :return:  客户端各队列和消费组偏移状态

    '''
    restatus = {}
    all_queue = {"articlesqueuekey":["artspout"],"outqueuekey":["artcompspout","outspout","outspoutxxy"],"outcompqueuekey":["outcompspout"]}
    for i in all_queue.keys():
        for j in all_queue[i]:
            o = kafkastatus(_broker_hosts, _zookeeper_hosts, i, j)
            restatus["%s_%s" % (i,j)]=o.status()
    return restatus


if __name__ == "__main__":
    pass
    # o = kafkastatus("python.zy.com:9092","python.zy.com:2181","outqueuekey","outspoutxxy")
    # print o.status()
    # print storm_queue_status("python.zy.com:9092","python.zy.com:2181")
    # print storm_queue_status("storm01.pz.com:9092,storm02.pz.com:9092,storm03.pz.com:9092","storm01.pz.com:2182,storm02.pz.com:2182,storm03.pz.com:2182")