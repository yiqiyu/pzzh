# -*- coding: utf-8 -*-
__author__ = 'wangyi'

from elasticsearch import Elasticsearch

class esutils():
    '''
    es 相关工具
    '''
    def __init__(self,_es_url):
        '''
        设置es链接地址 http://es.pz.com:9200
        :param _es_url:
        '''
        self.es_url = _es_url
        self.es = Elasticsearch(hosts=self.es_url[7:])

    def get_art_comanpy(self,company_index,id):
        '''
        获取es公司文章
        :param company_index: 公司索引
        :param id: 文章ID
        :return: 公司文章
        '''
        res = self.es.get(index=company_index, doc_type="article", id=id)
        return res["_source"]

    def get_art(self,id):
        '''
        获取es全局文章
        :param id: 文章ID
        :return:
        '''
        res = self.es.get(index="articles", doc_type="article", id=id)
        return res["_source"]


    def upload_art(self,wz):
        '''
        更新全局文章
        :param wz:  文章
        :return:
        '''
        indexname = "articles"
        type_name = "article"
        res = self.es.update(index=indexname, doc_type=type_name, id=wz["uuid"], body=wz)
        return res

    def upload_art_company(self,company_index,wz):
        '''
        更新公司文章upload to es
        :param wz:
        :return:
        '''
        type_name = "article"
        res = self.es.update(index=company_index, doc_type=type_name, id=wz["uuid"], body=wz)
        return res

    def exists_art(self,_id):
        '''
        判断全局文章是否存在
        :param id: uuid
        :return: True  Flase
        '''
        indexname = "articles"
        type_name = "article"
        res = self.es.exists(index=indexname, doc_type=type_name, id=_id)
        return res

    def exists_art_company(self,company_index,_id):
        '''
        判断公司文章是否存在
        :param id: uuid
        :return: True  Flase
        '''
        type_name = "article"
        res = self.es.exists(index=company_index, doc_type=type_name, id=_id)
        return res

    def get_media(self,mid):
        '''
        获取es media
        :param id: mid
        :return:
        '''
        res = self.es.get(index="medias", doc_type="media", id=mid)
        return res["_source"]

    def update_media(self,media):
        '''
        更新媒体
        :param media:  媒体
        :return:
        '''
        res = self.es.update(index="medias", doc_type="media",body=media,id=media["mid"])
        return res

if __name__ == "__main__":
    eu = esutils("http://es.zy.com:9200")
    print(eu.exists_art("5991541839391748747"))
    print(eu.exists_art_company("co_mi_xiaomitv","5991541839391748747"))
    print(eu.get_art("5991541839391748747"))
    print(eu.get_art_comanpy("co_mi_xiaomitv","5991541839391748747"))


