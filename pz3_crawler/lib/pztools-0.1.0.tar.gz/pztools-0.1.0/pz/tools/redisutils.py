# -*- coding: utf-8 -*-
__author__ = 'wangyi'

import redis

class redis_client():

    def __init__(self,_ip,_port,_passwd,_db=0):
        '''
        设置链接参数
        :param _ip:  redis_ip
        :param _port:  redis_port
        :param _passwd:  redis_passwd
        '''

        self.__pool = redis.ConnectionPool(host=_ip,       \
        port=_port, db=_db,max_connections=1, password=_passwd)

        self.rc = redis.Redis(connection_pool=self.__pool)

    def getclient(self):
        '''
        获取redis 客户端
        :return:  redis客户端
        '''
        return self.rc

if __name__ == "__main__":
    # rc = redis_client("python.zy.com",6381,"pzzh123456").getclient()
    # ks = rc.keys("c:*")
    # for k in ks:
    #     print(k)
    rc = redis_client("es.zy.com", 6381, "pzzh123456",1).getclient()
    ks = rc.keys("c:*")
    for k in ks:
        print(k)


