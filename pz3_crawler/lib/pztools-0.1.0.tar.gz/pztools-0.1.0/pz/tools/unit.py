# -*- coding: utf-8 -*-
import hashlib
from urllib.parse import urlparse
from urllib.parse import urljoin
import re
import copy
import sys
from bs4 import Comment

# reload(sys)
# sys.setdefaultencoding('utf-8')
import tld
import html2text

def md5(ob):
    m2 = hashlib.md5()
    m2.update(ob)
    return m2.hexdigest()

def url_get_params(url):
    rd= {}
    if '?' in url:
        paramstr = url.split('?')[1]
        for pr in paramstr.split('&'):
            if(len(pr)>2):
                kv = pr.split('=')
                rd.update({kv[0]:kv[1]})
    return rd

def url_analyze(url):
    d=urlparse.urlsplit(url)
    ds=tld.get_tld(url,as_object=True)
    return {'hostname':d.hostname,'url_link':d.scheme+'://'+d.hostname+d.path+'?'+d.query,'domoin':ds.tld}

def con_trim(data):
    data=data.strip()
    return data

def filter_tag(soup,filters):
    d=[]
    try:
        if isinstance(soup,list) :
            for s in soup:
                for f in filters :
                    name = f['name']
                    attrs = f['attrs']
                    titags = s.findAll(name,attrs=attrs)
                    fd=False
                    for k,v in attrs.items() :
                        try:
                            if s.attrs[k] == v :
                                fd=True
                            else :
                                fd=False
                        except:
                            f=False
                    if fd and name == s.name:
                         d.append(s)
                    if titags is not None :
                        if s in titags :
                            d.append(s)

                    for ext_tag in s.findAll(name,attrs=attrs):
                        try:
                            delf=False
                            if 'data' in f :
                                check_text = f['data'].replace('\s','').strip()

                                #todo if unicode(check_text) == unicode(ext_tag.text.replace('\s','').strip()) :
                                if check_text == ext_tag.text.replace('\s', '').strip():
                                    delf=True
                            else:
                                delf=True
                            if delf:
                                ext_tag.extract()
                        except:
                            pass

            for de in d :
                try:
                    soup.remove(de)
                except:
                    pass
        else :
                for f in filters :
                    name = f['name']
                    attrs = f['attrs']
                    for ext_tag in soup.findAll(name,attrs=attrs):
                        try:
                            delf=False
                            if 'data' in f :
                                check_text = f['data'].replace('\s','').strip()
                                #todo if unicode(check_text) == unicode(ext_tag.text().replace('\s','').strip()) :
                                if check_text == ext_tag.text().replace('\s', '').strip():
                                    delf=True
                            else:
                                delf=True
                            if delf:
                                ext_tag.extract()
                        except:
                            pass
    except:
        pass
    return soup


def img_url_tools(imgurl,current_url):
    return urljoin(current_url,imgurl)

def deal_imgtag_indata(data,current_url):
    try:
        ud={}
        imgtag=re.compile('<img.*?(?:>|\/>)',re.I).findall(data)
        for imgurl in imgtag :
            src=re.compile('src=[\"\'][^\"\']+[\"\']').findall(imgurl)
            for u in src:
                try:
                    url = u[5:-1]
                    nowhttpurl='''<img src="%s" />''' % img_url_tools(url,current_url) #u[0:5]+img_url_tools(url,current_url)+u[-1:]
                    ud.update({imgurl:nowhttpurl})
                except:
                    pass
        for u,url in ud.items():
            data=data.replace(u,url)
    except:
        pass
    while data.startswith('<br>'):
            data=data[4:]
    return data

def find_last_tags(data):
    data=re.sub(re.compile('<br[\s]*\/?>',re.I),'</p><p>',data)
    imgregex = re.compile('<img[\>]*>',re.I)
    isets =  imgregex.findall(data)
    data=re.sub(re.compile('<p[^>]+>',re.I),'<p>',data)
    for im in isets:
        data = data.replace(im,'</p>%s<p>' % im)
    if not  data.strip().lower().endswith('</p>'):
        data=data + '</p>'
    data=re.sub(re.compile('<\/?p>',re.I),'</p><p>',data)
    if not data.strip().lower().startswith('<p'):
        data="<p>" + data
    if data.strip().lower().endswith('<p>'):
        data=data[:-3]
    regexs='<p>[\s\n\r\t]*</p>'
    data = re.sub(re.compile(regexs,re.IGNORECASE),'',data)
    return data

def htmlTxt_clean(tags,ifImg=True):

    data=''
    if not ifImg:
        tags=clean_stylescript(tags)
    else:
        # 如果ifImg is true :保留图片
        tags=clean_stylescriptother(tags)

    if tags is None :
        return tags
    if isinstance(tags, list):
        for ob in tags :

             data=data+ob.prettify()
    else :
            data = data+tags.prettify()
    try:

        data = data_tags_clean(data)

    except:
        pass
    return data

def data_tags_clean(data):
    data=data.replace('\n','')

    data = rep_list(data)

    regexs= '\ssrc=\"'
    data = re.sub(re.compile(regexs,re.IGNORECASE),' src !=\"',data)

    regexs= '([\s]+((([\S]+[^!]=(\"[^\"]*\"|[\d]+)))[\s]?)*>)'
    data = re.sub(re.compile(regexs,re.IGNORECASE),'>',data)

    regexs= '\ssrc !=\"'
    data = re.sub(re.compile(regexs,re.IGNORECASE),' src=\"',data)

    regexs= '<br[\s]*[/]?>([\s,\n,\r]*)'
    data = re.sub(re.compile(regexs,re.IGNORECASE),'<br>',data)

    regexs='</?body>|</?html>'
    data = re.sub(re.compile(regexs,re.IGNORECASE),'',data)
    #
    regexs='<p>[\s]*<span>[\s]*<br/>[\s]*</span>[\s]*</p> '
    data = re.sub(re.compile(regexs,re.IGNORECASE),'',data)

    data=data.strip()

    data = find_last_tags(data)

    regexs= '<p>([\s,\n,\r]*)</p>'
    data = re.sub(re.compile(regexs,re.IGNORECASE),'',data)

    data = data.replace("&quot;","\"")
    data = data.replace("&amp;","&")
    data = data.replace("&lt;","<")
    data = data.replace("&gt;",">")
    data = data.replace("&nbsp;"," ")
    return data

def rep_list(data):
    try:
        replist=['<img','<p','<br','</p','<tr','<td''</tr','</td','</stromg','</em','</h1','</h2','</h3','</h4','</h5','</h6','<stromg','<em','<h1','<h2','<h3','<h4','<h5','<h6','<video','</video']
        regexs='<.*?(?:>|\/>)'
        findsets = re.compile(regexs,re.IGNORECASE).findall(data)
        for find in findsets:
            f=False
            for sp in replist:
                if find.lower().startswith(sp):
                     f=True
                     continue
            if not f:
                data = data.replace(find,'')
    except:
        pass
    return data



def clean_stylescript(content_Tag):
    content_Tag_b = copy.copy(content_Tag)
    if isinstance(content_Tag, list):
        t_tag =[]
        for p in content_Tag :
            t_tag.append(clean_stylescript(p))
        return t_tag
    else:
        try:
            [comment.extract() for comment in  content_Tag_b.findAll(text=lambda text:isinstance(text, Comment))]
            [script.extract() for script in content_Tag_b.findAll('script')]
            [style.extract() for style in content_Tag_b.findAll('style')]
            [img.extract() for img in content_Tag_b.findAll('img')]
            [link.extract() for link in content_Tag_b.findAll('link')]
            [meta.extract() for meta in content_Tag_b.findAll('meta')]
            [display.extract() for display in content_Tag_b.findAll(attrs={'style':re.compile('(.)*display:none(.)*')})]
        except:
            pass
    return content_Tag_b

def clean_stylescriptother(content_Tag):
    content_Tag_b = copy.copy(content_Tag)
    if isinstance(content_Tag, list):
        t_tag =[]
        for p in content_Tag :
            t_tag.append(clean_stylescriptother(p))
        return t_tag
    else:
        try:
            [comment.extract() for comment in  content_Tag_b.findAll(text=lambda text:isinstance(text, Comment))]
            [script.extract() for script in content_Tag_b.findAll('script')]
            [style.extract() for style in content_Tag_b.findAll('style')]
            [img.extract() for img in content_Tag_b.findAll('img',attrs={"src":re.compile('(.*)gif',re.I)})]
            [link.extract() for link in content_Tag_b.findAll('link')]
            [meta.extract() for meta in content_Tag_b.findAll('meta')]
            [display.extract() for display in content_Tag_b.findAll(attrs={'style':re.compile('(.)*display:none(.)*')})]
        except:
            pass
    return content_Tag_b

def find_htmlImg(tags,root_path=''):
    res=[]
    try:
        if isinstance(tags, list):
            for ob in tags :
                imgset=ob.findAll('img')
                if len(imgset) >0 :
                    for img in imgset:
                        src = img.get('src')
                        if src is not None :
                            res.append(root_path+src)
        else:
            imgset=tags.findAll('img')
            if len(imgset) >0 :
                for img in imgset:
                    src = img.get('src')
                    if src is not None :
                        res.append(root_path+src)
    except:
        pass
    return res

def dict2querstr(qDict):
        '''
        字典转换为查询串
        :param qDict:  字典
        :return:  查询串
        '''
        querystr = ''
        for i in qDict:
            querystr = '%s&%s=%s' % (querystr,i,qDict[i])
        if len(querystr) > 0:
            querystr = querystr[1:]
        return querystr

def querystr2dict(qstr):
    '''
    查询串转换为字典
    :param qstr:  查询串
    :return:  字典
    '''
    params = {}
    if '&' in qstr :
        if qstr.index('&'):
            qList = qstr.split('&')
            for i in qList:
                if i == '' :
                    continue
                iList = i.split('=')
                params[iList[0]] = iList[1]
    else:
        if '=' in qstr:
            qstrz = qstr.split('=')
            params[qstrz[0]] = qstrz[1]
    return params

def clearurl(url):
    '''
    function clearurl : 清理URL  保留host + path  清理 ＃ [todo: 如果存在特别的URL特征过滤，可以增加这里的处理]
    :param: url: URL
    :return: 清理后URL
    '''
    params = {}
    if '#' in url :
        if url.index('#'):
            url = url.split('#')[0]

    if '?' in url  :
        if url.index('?'):
            url_params = url.split('?')
            url = url_params[0]
            params = querystr2dict(url_params[1])

    return url,params


def sorlparams(params):
    '''
    function orderparams : 排序参数并返回排序后的查询字符串
    :param params: 参数串 或者 post
    :return: 排序后拼接的查询串
    '''
    if isinstance(params, str):
        if '&' in params:
            params = params.split('&')
            params.sort()
            return '&'.join(params)
        elif '=' in params :
            return params
    elif isinstance(params, unicode):
        if '&' in params:
            params = params.split('&')
            params.sort()
            return '&'.join(params)
        elif '=' in params :
            return params
    return ''

def geturlsolrparams(url):
    if '?' in url:
        url,t_params = clearurl(url)
        querystr =  dict2querstr(t_params)
        querystr =  sorlparams(querystr)
        url=url+'?'+querystr

    url.replace('/./','/')
    i=0
    while '/../' in url and i < 1000:
        i+=1
        urlsets = url.split('/')
        urlsets.remove(urlsets[urlsets.index('..')-1])
        urlsets.remove('..')
        url = '/'.join(urlsets)
    return url

def spliturl(url):
    d=urlparse.urlsplit(url)
    u_left=d.scheme+'://'+d.hostname
    u_right=url[url.index(d.hostname)+len(d.hostname):]
    return u_left,u_right


def markdown_translate( sources):
    '''
    转换为markdown格式
    '''
    h = html2text.HTML2Text()
    h.ignore_links = True
    st = h.handle(sources)
    #todo return unicode(st)
    return st
