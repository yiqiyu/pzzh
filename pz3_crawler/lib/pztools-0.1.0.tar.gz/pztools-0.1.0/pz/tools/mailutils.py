# -*- coding: utf-8 -*-
__author__ = 'wangyi'

import smtplib
from email.mime.text import MIMEText
from email.header import Header



class mail_client():
    def __init__(self):

        self.sender="grout_pz@qq.com"
        self.smtpserver= 'smtp.qq.com'
        self.password = 'uvhdfluxturneccd'
        self.username = 'grout_pz@qq.com'

    def send(self,_title,_body,_recs):
        '''
        发送邮件
        :param _title:
        :param _body:
        :param _recs: ['think10@qq.com','421658710@qq.com','602846187@qq.com']
        :return:
        '''
        receiver = _recs
        subject = _title

        msg = MIMEText(_body,"html","utf-8")

        msg['Subject'] = subject
        msg["From"] = self.sender
        smtp = smtplib.SMTP_SSL(self.smtpserver,port=465)
        smtp.connect(self.smtpserver,port=465)
        smtp.login(self.username, self.password)
        smtp.sendmail(self.sender, receiver, msg.as_string())
        smtp.quit()
# if __name__ == "__main__":
#
#     _body = '''
#         <html><body>sdfsadfasdf</body></html>
#     '''
#     mc.send("我的标题",_body,["think10@qq.com"])