# -*- coding: utf-8 -*-
__author__ = 'wangyi'

import re

def proc_title(title):
    # '''
    # 标准化标题处理:标题出现的空格和HTML代码要全去除。 2.出现的标点符号要全角、半角统一 3.英文全部小写。
    # :param title:  标题
    # :return: 规则化以后的标题
    # '''
    title = title.replace(" ","")
    title = title.replace("\n","")
    title = title.replace("\t","")
    title = title.replace('　', "")
    title = title.replace('。','.')
    title = title.replace('，', ',')
    title = title.replace('！', '!')
    title = title.replace('”', '"')
    title = title.replace("‘","'")
    title = title.lower()


    title = re.compile("<[^>]+>", re.I).sub("", title)
    return title


if __name__ == "__main__":
    # dc = "<title>我。饿<html>想 我是海 GTKD。，,！‘”</title>"
    # print(proc_title(dc))
    pass
