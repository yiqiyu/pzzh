# -*- coding: utf-8 -*-
__author__ = 'wangyi'


import json
def get_es_all_company_indexs(rc):
    '''
    返回es中所有的公司索引列表
    :param: rc es 接口对应的redis
    :return: es_index_list
    '''
    cs_keys = rc.keys("c:*")
    company_indexs = []
    for c_key in cs_keys:
        try:
            c_val = rc.get(c_key)
            c_conf = json.loads(c_val)
            company_indexs.append(c_conf["es_index"])
        except:
            pass

    return company_indexs

def get_all_companys(rc):
    '''
    返回es中所有的公司索引对象 {es_index:xx,es_host:xx}
    :param: rc es 接口对应的redis
    :return: es_index_list
    '''
    cs_keys = rc.keys("c:*")
    company_indexs = []
    for c_key in cs_keys:
        try:
            c_val = rc.get(c_key)
            c_conf = json.loads(c_val)
            company_indexs.append({"es_index":c_conf["es_index"],"es_host":c_conf["es_host"]})
        except:
            pass
    return company_indexs

def get_all_companyname(rc):
    '''
    返回es中所有的公司名称
    :param: rc es 接口对应的redis
    :return: company_list
    '''
    cs_keys = rc.keys("c:*")
    company_indexs = []
    for c_key in cs_keys:
        try:
           company_indexs.append(c_key[2:])
        except:
            pass
    return company_indexs


def get_company_by_id(rc,company_id):
    '''
    返回es中指定公司索引对象 {es_index:xx,es_host:xx}
    :param: rc es 接口对应的redis
    :return: es_index_list
    '''
    company_indexs = {}

    try:
        c_val = rc.get("c:%s" % company_id)
        c_conf = json.loads(c_val)
        company_indexs["es_index"]  = c_conf["es_index"]
        company_indexs["es_host"] = c_conf["es_host"]
    except:
        pass
    return company_indexs


if __name__ == "__main__":
    from pz.tools.redisutils import *
    rc = redis_client("python.zy.com", 6381, "pzzh123456").getclient()
    print(get_all_companyname(rc))
