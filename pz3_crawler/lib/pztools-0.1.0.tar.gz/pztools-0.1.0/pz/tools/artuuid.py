# -*- coding: utf-8 -*-
__author__ = 'wangyi'

from uuid import uuid1

def vart_uuid(_url):
    '''
    生成虚拟文章的uuid
    :param _url:  虚拟文章的URL
    :return:  返回hash string
    '''
    return str(hash(_url))

def art_uuid(_code,_url):
    '''
    真实文章的uuid 生成
    :param _code:   代码  或者规则化后的 标题,在不同类型的实体文章中,请使用对应的代码
    :param _url: 实体文章的URL
    :return: 返回hash string
    '''
    re_uuid = None
    try:
        url = _url.split("#")[0]
        re_uuid = str(hash("%s_%s" % (_code, url)))
    except Exception as e:
        re_uuid = str(uuid1())
    return re_uuid