# -*- coding: utf-8 -*-
__author__ = 'wangyi'

import jieba.analyse
from simhash import Simhash

ONE_STR = 0xFFFFFFFFFFFFFFFF
def simhash(txt):
    '''
    返回文本的simhash
    :param txt: 文本
    :return: simhash 值
    '''
    fw = jieba.analyse.extract_tags(txt,withWeight=True)
    return Simhash(fw).value

def distanceB(sv1,sv2):
    '''
    计算simhash 距离
    :param sv1: long simhash
    :param sv2: long simhash
    :return:  simhash 距离
    '''
    x = (sv1 ^ sv2) & ONE_STR
    ans = 0
    for i in bin(x):
        if i=="1":
            ans += 1
    return ans

def distance(sv1,sv2):
    '''
    计算simhash 距离
    :param sv1: long simhash
    :param sv2: long simhash
    :return:  simhash 距离
    '''
    x = (sv1 ^ sv2) & ((1 << 64) - 1)
    ans = 0
    while x:
        ans += 1
        x &= x - 1
    return ans

def simstr2x4(simhash_str):
    '''
    将simhash的16进制字符串，转换为4个成员的列表
    :param simhash_str:
    :return: simhash 列表
    '''
    s = long(simhash_str)
    s = "%x" % s
    return [s[0:4],s[4:8],s[8:12],s[12:]]

def sim4x2long(simhash_4x):
    '''
    将16进制的simhash  转换为long 类型
    :param simhash_4x:  16进制simhash
    :return: long  simhash
    '''
    return long("0x" + simhash_4x, 16)

if __name__ == "__main__":
    sh = simhash(u"这里是待计算simhash的文本")
    print(sh)
    print(distance(12652998664164589316, 17201772817718030086))
    print(distanceB(12652998664164589316,17201772817718030086))
    s4 =  simstr2x4(str(sh))
    print(s4)
    bs4 = "".join(s4)
    print(bs4)
    print(sim4x2long(bs4))
