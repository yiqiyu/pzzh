proc_title 用来正则化处理标题

调用案例:
    from pz.tools.titleutils import proc_title

    dc = "<title>我。饿<html>想 我是海 GTKD。，,！‘”</title>"
    print(proc_title(dc))

返回:
    我.饿想我是海gtkd.,,!'"

title 是处理后的:

1.标题出现的空格和HTML代码要全去除。

2.出现的标点符号要全角、半角统一。

3.英文全部小写。


-------------------------------------
url_analyze  分析URL

调用:

from pz.tools.unit import url_analyze
_url = "http://www.pz.com?aa=bb&cc=123"
reobj = url_analyze(_url)

返回:
reobj = {'hostname':"主机名称",'url_link':"链接",'domoin':"域名"}

--------------------------------------
geturlsolrparams  标准化URL

调用:

from pz.tools.unit import geturlsolrparams
_url = "http://www.pz.com?aa=bb&cc=123"
url = geturlsolrparams(_url)

返回:
url  对querystring 排序,去掉锚点后的URL

-------------------------------------

def art_uuid(_code,_url):
    '''
    真实文章的uuid 生成
    :param _code:   代码  或者规则化后的 标题,在不同类型的实体文章中,请使用对应的代码
    :param _url: 实体文章的URL
    :return: 返回hash string
    '''
调用:

from pz.tools.artuuid import art_uuid
print(art_uuid("http://art_url"))
---------------------------------------
def vart_uuid(_url):
    '''
    生成虚拟文章的uuid
    :param _url:  虚拟文章的URL
    :return:  返回hash string
    '''


from pz.tools.artuuid import vart_uuid
print(vart_uuid("http://vart_url"))

esutils 使用案例：

    eu = esutils("http://es.zy.com:9200")
    print(eu.exists_art("5991541839391748747"))
    print(eu.exists_art_company("co_mi_xiaomitv","5991541839391748747"))
    print(eu.get_art("5991541839391748747"))
    print(eu.get_art_comanpy("co_mi_xiaomitv","5991541839391748747"))

hbaseutils 使用案例：

    hd = hbasedao("hbase.zy.com",9099)
    print(hd.exists("g_zbzb","douyu:dinner"))

redisutils 使用案例：

    rc = redis_client("python.zy.com",6381,"pzzh123456").getclient()
    ks = rc.keys("c:*")
    for k in ks:
        print(k)

simhashutils 使用案例：

    sh = simhash("这里是待计算simhash的文本")
    print(sh)
    print distance(12652998664164589316,17201772817718030086)
    s4 =  simstr2x4(str(sh))
    print(s4)
    bs4 = "".join(s4)
    print(bs4)
    print(sim4x2long(bs4))


datetimeutils 使用案例：

    print(baidu_str2dt("4分钟前"))
    print(baidu_str2dt("20小时前"))
    print(baidu_str2dt("2016年06月24日 07:00"))
    # print(baidu_str2dt("我都不知道这里是啥样的值,分钟前,小时前,2016年06月24日 07:002016年06月24日 07:002016年06月24日 07:002016年06月24日 07:00"))
    # print(curr_dtstr()[:-6])
    print(baijia_str2dt("07:50"))
    print(baijia_str2dt("07-11"))
    print(baijia_str2dt("2015-12-09"))
    # create_time = params["art_dt"][:11] + soup.find('span', attrs={'class': 'time'}).text[-5:] + ':00'
    print(baijia_str2dt("2015-12-09")[:11] + "07月13日 07:50"[-5:] + ":00")



